#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

void plan_120();
void plan_150();
void plan_200();
void plans(int);
void registration();
void user_services(int);
void login(int);
void claimtype(int);
void admin();
void search_users_by_id();
void claim_history();
void specific_claim();
void admin_services();
void claim_lifetime();
void claim_annual();
void user();
void edit(int);
void profile(int);
void subscribe(int);
void amount(int);
void verify(int);
void user_history(int);
void claim(int);
void recipet(int);
void main(){
    int choice;
    int userid;
    system("cls");
	printf("\t<<---------ZeeMediLife Insurance Company----------->>\t");
	printf("\n1.Register");
	printf("\n2.Login");
	printf("\n3.Admin");
	printf("\nEnter the service you want (1 |2 |3 ): ");
	scanf("%d",&choice);fflush(stdin);
	switch(choice)
	{
		case 1:
			registration();
			break;
		case 2:
		   login(userid);
			break;
		case 3:
			admin();
			break;
		default:
			printf("\nInvalid option");getch();
			main();
	}			
}

void registration(){
	system("cls");
	printf("\t\t<<---------------------REGISTRATION---------------------->>\t\t");
	char first_name[20];
	char ans[5];
	char health_history[50];
	char second_name[20];
	char address[20];
	char email[50];
	int day,month,year;
	char phone[20];
    char password[10];
    char gender[10];
	int start=1,end=100,id;
	FILE *f1;
	FILE *f2;
	f1 = fopen("newuser.txt", "a");
	f2 = fopen("health_history.txt","a");
    if(f1==NULL  || f2==NULL)
    {
    printf("\nFIle could not be opened!\n"); fclose(f1);getch(); main();
    }
    srand(time(NULL));
	id=(rand()%(end-start+1))+start;
	printf("\n Your id is %d",id);
    printf("\nEnter subscriber details:\n\n");
    printf("\nEnter your first name: \n");gets(first_name);fflush(stdin);
    printf("\nEnter your last name: \n"); gets(second_name);fflush(stdin);
    printf("\nEnter your date of birth [day]: \n");scanf("%d",&day);fflush(stdin);
    if((day>31)|| (day<1)){
    	printf("\ninvalid day");getch();main();
	}
    printf("\nEnter your date of birth [month]: \n");scanf("%d",&month);fflush(stdin);
    if((month>12)||(month<1)){
    	printf("\ninvalid month");getch();main();
	}
    printf("\nEnter your date of birth [year in AD]: \n");scanf("%d",&year);fflush(stdin);
    if(year>2021 || year<1900){
    	printf("\ninvalid year");getch();main();
	}
	printf("\nEnter your gender(male-m | female-f| bisexual-bi): \n");gets(gender);fflush(stdin);
    printf("\nEnter your address: \n");gets(address);fflush(stdin);
    printf("\nEnter your contact number: \n");gets(phone);fflush(stdin);
    if(strlen(phone)!=10 && strlen(phone)!=14 ){
    	printf("\nInvalid number");getch();main();
	}
    printf("\nEnter your email adress: \n");gets(email);fflush(stdin);
    printf("\nEnter your password: \n");gets(password);fflush(stdin);
    fprintf(f1,"%d %s %s %d %d %d %s %s %s %s %s\n",id,first_name,second_name,day,month,year,gender,address,phone,email,password);
    fclose(f1);
    printf("\nDo you have any health history?(y-yes| n-no)\n");gets(ans);fflush(stdin);
    if((strcmp(ans,"y")==0) || (strcmp(ans,"Y")==0))
	{
	    printf("\nEnter your health history in short.Use underscore instead of space: ");gets(health_history);fflush(stdin);
	    fprintf(f2,"%d %s\n",id,health_history);
	    fclose(f2);
	}
    else{
		fprintf(f2,"%d %s\n",id,"no");
		fclose(f2);}
    printf("\n\nYou are successfully registered.\n"); getch();
    main();
}

void login(int userid){
	FILE *f1;
	int id,day,month,year;
	char first_name[20];
	char second_name[20];
	char address[20];
	char email[20];
	char phone[20];
    char password[10];
    char pw[10];
    char gender[10];
    system("cls");
    printf("\t\t<<-------------------------LOG IN----------------------------------->>\t\t");
    printf("\nenter your userid: ");
	scanf("%d",&userid);fflush(stdin);
	printf("\nenter your password: ");
	gets(pw);fflush(stdin);
    f1=fopen("newuser.txt","r");
    if(f1==NULL)
    {
    	printf("\nFIle could not be opened!\n");fclose(f1); getch();main();
    }
    while(fscanf(f1,"%d %s %s %d %d %d %s %s %s %s %s",&id,first_name,second_name,&day,&month,&year,gender,address,phone,email,password)==11)
	{
    	if((userid==id) && (strcmp(pw,password)==0))
		{
		   fclose(f1);
		   user_services(userid);
		   return;	
		}
	}
	printf("\nInvalid id password");getch();
	fclose(f1);
	main();	
}

void user_services(int userid){
	int service;
	char choice[10];
	system("cls");
	printf("\n\t<<--------HELLO USER-------->>\n\t");
	printf("\n1.Profile");
	printf("\n2.Subscribe");
	printf("\n3.Claim");
    printf("\n4.Claim history");
    printf("\n5.Edit your profile");
	printf("\n6.Exit");
	printf("\nWhich service(1 | 2 | 3| 4 |5 |6)");
	scanf("%d",&service);fflush(stdin);
	switch(service){
		case 1:
			profile(userid);
			break;
		case 2:
			subscribe(userid);
			break;
		case 3:
		    verify(userid);
			break;
		case 4:
			user_history(userid);
			break;
	    case 5:
	    	edit(userid);
	    	break;
	    case 6:
	    	main();
	    	break;
		default:
		    printf("\nInvalid option");getch();
		    user_services(userid);
			break;	
	}
}

void subscribe(int userid){
	FILE *f1,*f2;
	int uid,a;
	float balance;
	char choice[10];
	f2=fopen("subs.txt","a");
	f1=fopen("subs.txt","r");
	if(f1==NULL && f2==NULL)
	{
		printf("\nFile could not be opened!\n");getch();fclose(f1);fclose(f2);user_services(userid);
	}
    while(fscanf(f1,"%d %d %s %f",&uid,&a,choice,&balance)==4){
    	if(userid==uid){
    		system("cls");    		
			printf("\t\t YOU ARE ALREADY SUBSCRIBED\t\t");getch();fclose(f1);fclose(f2);user_services(userid);
		}
	} 
	fclose(f2);
	fclose(f1);
	plans(userid);
	}

void plans(int userid)
{	
    system("cls");
    printf("\t\t<<---------------------SUBSCRIBE---------------------->>\t\t");
    int age,p;
	int kl=200;
    FILE *f1;
    f1=fopen("subs.txt","a");
    if(f1==NULL)
    {
    	printf("\nFIle could not be opened!\n");fclose(f1); getch();user_services(userid) ;
    }
    fprintf(f1,"%d",userid);
	printf("\nEnter your age :");
	scanf("%d",&age);
	age=age*365;/*since we also have 15 days in the questions*/
	if(age>19710){
		printf("\nSorry no services for you.");getch();
		user_services(userid);
	}	
	if(age>=15,age<=7300)
    {
    	printf("\nYou can choose from the following insurance plans\n");
		plan_120();
		plan_150();
    	plan_200();
        printf("\nwhich plan do you want to use?(120| 150 | 200) ");fflush(stdin);
    	scanf("%d",&p);
    	switch(p)
        {
			case 120:
				printf("\n----plan120----\n");
				fprintf(f1," %d",p);
	            break;
	        case 150:
	        	printf("\n-----plan150----\n");
				fprintf(f1," %d",p);
	            break;
	        case 200:
	        	printf("\n-----plan200----\n");
				fprintf(f1," %d",p);
	            break;
	        default:
				printf("\nInvalid choice\n");getch();fclose(f1);
				user_services(userid);
       }
    }
    else if (age>=7665,age<=14600)
    {
		printf("\nYou can choose from the following services\n");
		plan_150();
	    plan_200();
	    printf("\nWhich plan do you want to use(150 | 200) ");fflush(stdin);
	    scanf("%d",&p);
		switch(p)
	    {
			case 150:
				printf("\n---plan150---\n");
				fprintf(f1," %d",p);
				break;
			case 200:
				printf("\n---plan200---\n");
				fprintf(f1," %d",p);
				break;
			default:
				printf("\nInvalid choice\n");getch();fclose(f1);
				user_services(userid);
       }   
    }
    else if (age>=14965,age<=19710)
	{
	    printf("\nYou can only choose plan200 \n");
	    printf("\nPlan 200\n");
	    printf("You must pay RMB200 as monthly premium\n");
	    printf("You can get RMB200 per day as bed charges\n");
		printf("You can get RMB700 per day as ICU charges\n");
		printf("Hospital fees,surgical fees and other fees are paid according to the insurance company policy.\n");getch();
	    fprintf(f1," %d",kl);		
    }
    fclose(f1);
    claimtype(userid);
}
void plan_120()
   {
   
	printf("\nPlan120\n");
	printf("You must pay RMB120 as monthly premium\n");
	printf("You can get RMB120 per day as bed charges\n");
	printf("You can get RMB250 per day as ICU charges\n");
	printf("Hospital fees,surgical fees and other fees are paid according to the insurance company policy\n");
}
void plan_150()
	{
	
	printf("\nPlan150\n");
    printf("You must pay RMB150 as monthly premium\n");
    printf("You can get RMB150 per day as bed charges\n");
	printf("You can get RMB400 per day as ICU charges\n");
	printf("Hospital fees,surgical fees and other fees are paid according to the insurance company policy\n");
}
void plan_200()
   {
   
    printf("\nPlan 200\n");
    printf("You must pay RMB200 as monthly premium\n");
    printf("You can get RMB200 per day as bed charges\n");
	printf("You can get RMB700 per day as ICU charges\n");
	printf("Hospital fees,surgical fees and other fees are paid according to the insurance company policy.\n");
}

void claimtype(int userid){
	system("cls");
	float k=0;
	char choice[10];
	FILE *f1;
	f1 = fopen("subs.txt","a");
	if(f1==NULL)
		{
		  printf("\nFIle could not be opened!\n");fclose(f1); getch();user_services(userid);
		}
	printf("Which claim type do you prefer?\n");
 	printf("\n1.Annual claim type.\n");
	printf("---In this claim type you can claim the insurance amount once in a year.\n");
	printf("--- Remember you can claim the amount only after the age of 60\n");
	printf("\n2.Lifetime claim type\n");
	printf("---In this claim type you can claim the insurance amount anytime you want until your claimable amount is finished.\n");
	printf("---Remeber you can claim the amount only after paying all the premimum\n");
	printf("\n Which claim type do you prefer?(Annual-0 | Lifetime-1) ");scanf("%s",choice);fflush(stdin);
	if(strcmp(choice,"0")==0 ||strcmp(choice,"1")==0){
		if(strcmp(choice,"0")==0){
			fprintf(f1," %s %d","annual",k);
			fclose(f1);
			amount(userid);}
		if(strcmp(choice,"1")==0){
			fprintf(f1," %s %d","lifetime",k);
			fclose(f1);
			amount(userid);}		
	}
    else{
    	printf("\nInvalid option");getch();
    	fclose(f1);
    	user_services(userid);
	}
}
void amount(int userid){
	int uid,a;
	float k=0,balance;
	char choice[10];
	char annual[10]="annual";
	char life[10]="lifetime";
	FILE *f1;
	FILE *f2;
	f1=fopen("subs.txt","r");
	f2=fopen("tempo.txt","a");
	if (f1==NULL && f2==NULL){
		printf("\nFIle could not be opened!\n");fclose(f1);fclose(f1); getch();user_services(userid);
	}
	while(fscanf(f1,"%d %d %s %f",&uid,&a,choice,&k)==4)
	{
		if(userid!=uid){
			fprintf(f2,"%d %d %s %f\n",uid,a,choice,k);
		}
		else
		{
			if(a==120 && strcmp(choice,annual)==0){
				balance=120000;
				printf("\nYou will have %f uploaded in your account",balance);getch();
			    fprintf(f2,"%d %d %s %f\n",uid,a,choice,balance);}
			if(a==120 && strcmp(choice,life)==0){
				balance=600000;
				printf("\nYou will have %f uploaded in your account",balance);getch();
			    fprintf(f2,"%d %d %s %f\n",uid,a,choice,balance);}
			if(a==150 && strcmp(choice,annual)==0){
				balance=150000;
				printf("\nYou will have %f uploaded in your account",balance);getch();
			    fprintf(f2,"%d %d %s %f\n",uid,a,choice,balance);}
			if(a==150 && strcmp(choice,life)==0){
				balance=750000;
				printf("\nYou will have %f uploaded in your account",balance);getch();
			    fprintf(f2,"%d %d %s %f\n",uid,a,choice,balance);}
			if(a==200 && strcmp(choice,annual)==0){
				balance=200000;
				printf("\nYou will have %f uploaded in your account",balance);getch();
			    fprintf(f2,"%d %d %s %f\n",uid,a,choice,balance);}
			if(a==200 && strcmp(choice,life)==0){
				balance=1000000;
				printf("\nYou will have %f uploaded in your account",balance);getch();
			    fprintf(f2,"%d %d %s %f\n",uid,a,choice,balance);}
     	}
    }
	fclose(f1);
	fclose(f2);
	remove("subs.txt");
	rename("tempo.txt","subs.txt");
	user_services(userid);
}

void profile(int userid){
	system("cls");
	printf("\t\t<<---------------------PROFILE---------------------->>\t\t");
	int id,a,uid,day,month,year;
	float k;
	char first_name[20];
	char health_history[100];
	char second_name[20];
	char address[20];
	char email[50];
	char phone[20];
    char password[10];
    char choice[10];
    char gender[10];
    FILE*f1;
	FILE*f2;
	FILE*f3;
	f1 = fopen("newuser.txt","r");
	f2=fopen("subs.txt","r");
	f3=fopen("health_history.txt","r");
	if(f1==NULL)
	if(f2==NULL)
	if(f3==NULL)
    {
    	printf("\nFIle could not be opened!\n");fclose(f1);fclose(f2);fclose(f3);getch();user_services(userid);
    }
    while(fscanf(f1,"\n%d %s %s %d %d %d %s %s %s %s %s",&id,first_name,second_name,&day,&month,&year,gender,address,phone,email,password)==11)
    {
    	if(userid==id)
		{ 
			printf("\n|id|   |name|           |DOB|   |gender|   |adress|    |phone|           |email|        |password|");
		    printf("\n %d  %s %s  %d %d %d     %s     %s    %s %s %s\n",id,first_name,second_name,day,month,year,gender,address,phone,email,password);
		}
	}
	while(fscanf(f2,"%d %d %s %f",&uid,&a,choice,&k)==4)
	{
		if(userid==uid)
		    {  
		        printf("\n----------------------------------------------\n");
		        printf("\n|id| |plantype|  |claimtype|   |balance|");
			    printf("\n%d    %d         %s     %f",uid,a,choice,k);
				}
	}
	while(fscanf(f3,"%d %s",&uid,health_history)==2)
	{
		if(userid==uid)
		{
			    printf("\n----------------------------------------------\n");
			    printf("\n|id|  |health history|");
			    printf("\n%d   %s",uid,health_history);getch();
				fclose(f1);
			    fclose(f2);
			    fclose(f3);user_services(userid);
			    }
	}      
    fclose(f1);
    fclose(f2);
    fclose(f3);
    printf("\n Data couldn't be found");getch();user_services(userid);return;
}
void edit(int userid){
	system("cls");
	printf("\t\t<<-----------EDIT MY INFO------------>>\t\t");
	char first_name[10],fname[10];
	char second_name[10],sname[10];
	char gender[10],gen[10];
	char address[10],add[10];
	char phone[10],num[10];
	char email[10],mail[10];
	char password[10],pw[10],ans[10];
	char health_history[10],health[10];
	int uid,id,d,m,y,x,n,z;
	FILE *f1;
	FILE *f2;
	FILE *f3;
	FILE *f4;
	f1=fopen("newuser.txt","r");
	f2=fopen("health_history.txt","r");
	f3=fopen("temp1.txt","a");
	f4=fopen("temp2.txt","a");
	if(f1==NULL &&f2==NULL && f3==NULL && f4==NULL){
		printf("\nFIle could not be opened!\n");fclose(f1);fclose(f2);fclose(f3);fclose(f4);getch();user_services(userid);
	}
    while(fscanf(f1,"%d %s %s %d %d %d %s %s %s %s %s",&id,first_name,second_name,&d,&m,&y,gender,address,phone,email,password)==11)
    {
    	if(userid!=id){
    		fprintf(f3,"\n%d %s %s %d %d %d %s %s %s %s %s",id,first_name,second_name,d,m,y,gender,address,phone,email,password);
		}
		else{
			printf("\nIf you do not want to change certain data, enter your previous data in that part");
			printf("\n\nEnter your first name: \n");gets(fname);fflush(stdin);
		    printf("\nEnter your last name: \n"); gets(sname);fflush(stdin);
		    printf("\nEnter your date of birth [day]: \n");scanf("%d",&x);fflush(stdin);
		    if((d>31)|| (d<1)){
		    	printf("\ninvalid day");getch();edit(userid);
			}
		    printf("\nEnter your date of birth [month]: \n");scanf("%d",&n);fflush(stdin);
		    if((n>12)||(n<1)){
		    	printf("\ninvalid month");getch();edit(userid);
			}
		    printf("\nEnter your date of birth [year in AD]: \n");scanf("%d",&z);fflush(stdin);
		    if(z>2021 || z<1900){
		    	printf("\ninvalid year");getch();edit(userid);
			}
			printf("\nEnter your gender(male-m | female-f| bisexual-bi): \n");gets(gen);fflush(stdin);
		    printf("\nEnter your address: \n");gets(add);fflush(stdin);
		    printf("\nEnter your contact number: \n");gets(num);fflush(stdin);
		    if(strlen(num)!=10 && strlen(num)!=14 ){
		    	printf("\nInvalid number");getch();edit(userid);
			}
		    printf("\nEnter your email adress: \n");gets(mail);fflush(stdin);
		    printf("\nEnter your password: \n");gets(pw);fflush(stdin);
			fprintf(f3,"\n%d %s %s %d %d %d %s %s %s %s %s",id,fname,sname,x,n,z,gen,add,num,mail,pw);
			}
		}
	while(fscanf(f2,"%d %s",&uid,health_history)==2){
		if(userid!=uid){
			fprintf(f4,"\n%d %s",uid,health_history);
		}
		else{
			printf("\nDo you have any health history?(y-yes| n-no)\n");gets(ans);fflush(stdin);
		    if((strcmp(ans,"y")==0) || (strcmp(ans,"Y")==0))
			{
			    printf("\nEnter your health history in short.Use underscore instead of space: ");gets(health);fflush(stdin);
			    fprintf(f4,"\n%d %s",uid,health);
			}
			else{
				fprintf(f4,"\n%d %s",uid,"no");}
			}
		}
	fclose(f2);
	fclose(f4);
	fclose(f1);
	fclose(f3);
	remove("newuser.txt");
	rename("temp1.txt","newuser.txt");
	remove("health_history.txt");
	rename("temp2.txt","health_history.txt");
	printf("\nYour data is edited successfully");getch();user_services(userid);
}

void user_history(int userid){
	system("cls");
	printf("\t\t<<---------------------CLAIM HISTORY---------------------->>\t\t");
	int uid,x,y,z,id;
	float room,icu,other,day,total,k,remaining_amount;
	FILE *f1;
	f1=fopen("claim.txt","r");
	if(f1==NULL){
		printf("\nYou have not claimed yet\n");fclose(f1);getch();user_services(userid);
	}
	printf("\n|id|  |room charge| |icu charge| |other charge| |days admitted| |total charge| |initial balance| |remaining balance| |date claimed|");
	while(fscanf(f1,"%d %f %f %f %f %f %f %f %d %d %d\n",&uid,&room,&icu,&other,&day,&total,&k,&remaining_amount,&x,&y,&z)==11)
	{
		if(uid==userid){
			printf("\n %d     %f    %f    %f    %f      %f     %f       %f       %d %d %d",userid,room,icu,other,day,total,k,remaining_amount,x,y,z);
		}
	}	fclose(f1);	getch();user_services(userid);
}
void verify(int userid){
	int uid,a;
	float k;
	char choice[10];
	FILE *f1;
	f1=fopen("subs.txt","r");
	if(f1==NULL){
		printf("\nData couldn't be found");getch();fclose(f1);user_services(userid);
	}
	while(fscanf(f1,"%d %d %s %f",&uid,&a,choice,&k)==4)
	{
		if(userid==uid){
			fclose(f1);
			claim(userid);
		}
	}
	printf("\nSubscribe to a plan first");getch();fclose(f1);user_services(userid);
}

void claim(int userid){
	system("cls");
	int uid,a,user_id=userid,c1,c2;
	char choice[10];
    float room,icu,other,k,total,remaining_amount,day;
    FILE *fp;
	FILE *fk;
	FILE *f1;
	FILE *f2;
	FILE *f3;
    printf("\t\t<<------------------------CLAIM----------------------------------->>\t\t");
	printf("\n Input your room charge per day: ");scanf("%f",&room);fflush(stdin);
	printf("\n Input your ICU charge per day: ");scanf("%f",&icu);fflush(stdin);
	printf("\n Input your other charge per day: ");scanf("%f",&other);fflush(stdin);
	printf("\n How many days were you admitted for? ");scanf("%f",&day);fflush(stdin);
	total=(room+icu+other)*day;
	time_t t;
	t = time(NULL);
	struct tm tm = *localtime(&t);
	fp= fopen("subs.txt","r");
	fk= fopen("claim.txt","a");
	f3= fopen("recipet.txt","a");
	f2=fopen("temp.txt","a");
	if(fp==NULL && fk==NULL && f3==NULL && f2==NULL){
		printf("\nFile could not be opened");fclose(fp);fclose(fk);fclose(f3);fclose(f2);getch();user_services(userid);
	}
	while(fscanf(fp,"%d %d %s %f",&uid,&a,choice,&k)==4)
		{
		   	if(userid==uid)
			   {
			   	if(total<k)
				   {
				   	remaining_amount=k-total;
			   		switch(a)
					   {
			   			case 120:
			   				if(room>120 || icu>250){
			   					printf("\nYour plan type doesn't cover the room charge");getch();fclose(fp);fclose(fk);fclose(f3);fclose(f2);
			   					user_services(userid);
							   }
							else{
								fprintf(fk,"%d %f %f %f %f %f %f %f %d %d %d\n",userid,room,icu,other,day,total,k,remaining_amount,tm.tm_mday, tm.tm_mon+1, tm.tm_year+1900);
								fprintf(f3,"%d %f %f %f %f %f %f %f %d %d %d\n",user_id,room,icu,other,day,total,k,remaining_amount,tm.tm_mday, tm.tm_mon+1, tm.tm_year+1900);
		                        fclose(fk);
		                        fclose(f3);
							}
						case 150:
							if(room>150 || icu>400){
			   					printf("\nYour plan type doesn't cover the room charge");getch();fclose(fp);fclose(fk);fclose(f3);fclose(f2);
			   					user_services(userid);
							   }
							else{
								fprintf(fk,"%d %f %f %f %f %f %f %f %d %d %d\n",userid,room,icu,other,day,total,k,remaining_amount,tm.tm_mday, tm.tm_mon+1, tm.tm_year+1900);
								fprintf(f3,"%d %f %f %f %f %f %f %f %d %d %d\n",user_id,room,icu,other,day,total,k,remaining_amount,tm.tm_mday, tm.tm_mon+1, tm.tm_year+1900);
		                        fclose(fk);
		                        fclose(f3);
							}
						case 200:
							if(room>200 || icu>700){
			   					printf("\nYour plan type doesn't cover the room charge");getch();fclose(fp);fclose(fk);fclose(f3);fclose(f2);
			   					user_services(userid);
							   }
							else{
								fprintf(fk,"%d %f %f %f %f %f %f %f %d %d %d\n",userid,room,icu,other,day,total,k,remaining_amount,tm.tm_mday, tm.tm_mon+1, tm.tm_year+1900);
								fprintf(f3,"%d %f %f %f %f %f %f %f %d %d %d\n",user_id,room,icu,other,day,total,k,remaining_amount,tm.tm_mday, tm.tm_mon+1, tm.tm_year+1900);
		                        fclose(fk);
		                        fclose(f3);
						   }
				        }
			       }
			    else{
					printf("\nSorry you can't claim. Insufficient amount");fclose(fp);fclose(fk);fclose(f3);fclose(f2);getch();user_services(userid);
			    }	
	        }
        } 
    printf("\n\t------SUCCESSFULLY CLAIMED------\n\t");
    printf("\nYour total was %f",total);getch();
	printf("\nYou have the following amount remaining %f",remaining_amount);getch();
	if(userid!=uid)
		{
			fprintf(f2,"%d %d %s %f\n",uid,a,choice,k);
		}
	else
		{
			fprintf(f2,"%d %d %s %f\n",uid,a,choice,remaining_amount);
		}
	fclose(f2);
	fclose(fp);
	remove("subs.txt");
    rename("temp.txt","subs.txt");
    recipet(userid);
}

void recipet(int userid){
	int id,day,month,year,a,uid,user_id,x,y,z;
	system("cls");
	printf("\n\t<<------------------DIGITAL RECIPET------------------->>\n\t");
	float room,icu,other,total,k,remaining_amount,balance,d;
	char first_name[20];
	char second_name[20];
	char address[20];
	char email[50];
	char phone[20];
    char password[10];
    char choice[10];
    char gender[10];
	FILE *f1;
	FILE *f2;
	FILE *f3;
	f1=fopen("newuser.txt","r");
	f2=fopen("subs.txt","r");
	f3=fopen("recipet.txt","r");
	if(f1==NULL && f2==NULL && f3==NULL){
		printf("\nfiles couldn't be found");fclose(f1);fclose(f2);fclose(f3);getch();user_services(userid);
	}
	while(fscanf(f1,"\n%d %s %s %d %d %d %s %s %s %s %s",&id,first_name,second_name,&day,&month,&year,gender,address,phone,email,password)==11){
		if (userid==id){
			printf("\nid: %d",id);
			printf("\nName: %s %s",first_name,second_name);
			fclose(f1);
		}
	}
	while(fscanf(f2,"%d %d %s %f",&uid,&a,choice,&k)==4){
		if(userid==uid){
			printf("\nPlan type :%d",a);
			printf("\nClaim type :%s",choice);
			fclose(f2);
		}
	}
	while(fscanf(f3,"%d %f %f %f %f %f %f %f %d %d %d",&user_id,&room,&icu,&other,&d,&total,&balance,&remaining_amount,&x,&y,&z)==11){
		if(userid==user_id){
			printf("\nRoom charge: %f",room);
			printf("\nICU charge: %f",icu);
			printf("\nOther charges: %f",other);
			printf("\nYou were admited for: %d",day);
			printf("\nTotal charge: %f",total);
			printf("\nYour previous amount: %f",balance);
			printf("\nYour remaining amount: %f",remaining_amount);
			printf("\n Date: %d %d %d",x,y,z);
			fclose(f3);
			printf("\nPress any key to continue");getch();remove("recipet.txt"),user_services(userid);
		}
	}	
}

void admin(){
	system("cls");
	printf("\t\t-------------------ADMIN LOG IN--------------------\t\t");
	char adminid[10],admn[10]="admin";
	char adminpw[10],pw[10]="admin123";
	printf("\nenter the admin id\n");
	gets(adminid);fflush(stdin);
	printf("\nenter the admin password\n");
	gets(adminpw);fflush(stdin);
    if (strcmp(adminid,admn)==0 && strcmp(adminpw,pw)==0)
	{
    	printf("\nhello admin\n");
    	admin_services();
	}
    else
    {
        printf("\nlog in failed\n");getch();
    	main();
	}
}

void admin_services(){
	int service;
	system("cls");
	printf("\t\t<<---------------------ADMIN SERVICES---------------------->>\t\t");
    printf("\n Hi admin");
    printf("\n1.Users");
    printf("\n2.Search users by user id");
    printf("\n3.View claim history");
    printf("\n4.View claim history of specific user");
    printf("\n5.Total amount claimed by Lifetime Claim Limit subscribers");
    printf("\n6.Total number of Annual Claim Limit subscribers who have exhausted all their eligible amount");
    printf("\n7.Exit");
    printf("\nWhich service?(1|2|3|4|6|7) ");
    scanf("%d",&service);
    switch(service)
	{
		case 1:
    		user();
    		break;
    	case 2:
    		search_users_by_id();
    		break;
    	case 3:
    		claim_history();
    		break;
    	case 4:
    		specific_claim();
    		break;
    	case 5:
    		claim_lifetime();
    		break;
    	case 6:
    		claim_annual();
    		break;
    	case 7:
    		main();
    		break;
    	default:
    		printf("\nInvalid choice");getch();
    		admin_services();
    		break;		
	}
}
    
void search_users_by_id(){
	system("cls");
	printf("\t\t<<---------------------PROFILE---------------------->>\t\t");
	int id,uid,a,day,month,year,userid;
	float k;
	char first_name[20];
	char health_history[50];
	char second_name[20];
	char address[20];
	char email[50];
	char phone[20];
    char password[10];
    char choice[10];
    char gender[10];
    FILE *f1;
	FILE *f2;
	FILE *f3;
    printf("\nEnter the user id to search: ");
    scanf("%d",&userid);fflush(stdin);
	f1 = fopen("newuser.txt","r");
	f2= fopen("subs.txt","r");
	f3= fopen("health_history.txt","r");
	if(f1==NULL)
	if(f2==NULL)
	if(f3==NULL)
    {
    	printf("\nFIle could not be opened!\n");fclose(f1);fclose(f2);fclose(f3);admin_services();getch(); return ;
    }
     while(fscanf(f1,"\n%d %s %s %d %d %d %s %s %s %s %s",&id,first_name,second_name,&day,&month,&year,gender,address,phone,email,password)==11)
    {
    	if(userid==id)
		{ 
			printf("\n|id|   |name|           |DOB|   |gender|   |adress|    |phone|           |email|        |password|");
		    printf("\n %d  %s %s  %d %d %d     %s     %s   %s %s %s\n",id,first_name,second_name,day,month,year,gender,address,phone,email,password);
		}
	}
    
	while(fscanf(f2,"%d %d %s %f",&uid,&a,choice,&k)==4)
	{
		if(userid==uid)
		    {  
		        printf("\n----------------------------------------------\n");
		        printf("\n|id| |plantype|  |claimtype|   |balance|");
			    printf("\n%d    %d         %s     %f",uid,a,choice,k);
				}
	}
	while(fscanf(f3,"%d %s",&uid,health_history)==2)
	{
		if(userid==uid)
		{
			    printf("\n----------------------------------------------\n");
			    printf("\n|id|  |health history|");
			    printf("\n%d   %s",uid,health_history);getch();
			    fclose(f1);
			    fclose(f2);
			    fclose(f3);
			    admin_services();
	    }
	printf("\n Data couldn't be found");getch();
	fclose(f1); 
	fclose(f2);
	fclose(f3);admin_services();
    }
}

void user(){
	system("cls");
	printf("\t\t<<---------------------USERS---------------------->>\t\t");
	FILE *f1;
	int id,day,month,year,userid;
	char first_name[20];
	char second_name[20];
	char address[20];
	char email[50];
	char phone[20];
    char password[10];
    char gender[10];
    f1=fopen("newuser.txt","r");
    if(f1==NULL)
    {
    	printf("\nData could not be found!\n"); getch();fclose(f1);admin_services();
    }
    printf("\n|id|   |name|           |DOB|   |gender|   |adress|    |phone|           |email|        |password|");
    while(fscanf(f1,"%d %s %s %d %d %d %s %s %s %s %s",&id,first_name,second_name,&day,&month,&year,gender,address,phone,email,password)==11)
	{
	    printf("\n %d  %s %s  %d %d %d     %s     %s   %s %s %s\n",id,first_name,second_name,day,month,year,gender,address,phone,email,password);
	}
	getch();fclose(f1);admin_services();
	}

void claim_history(){
	system("cls");
	printf("\t\t<<---------------------CLAIM HISTORY---------------------->>\t\t");
	int userid,x,y,z;
	float room,icu,other,day,total,k,remaining_amount;
	FILE *f1;
	f1=fopen("claim.txt","r");
	if(f1==NULL){
		printf("\nFile could not be opened\n");fclose(f1);admin_services();getch();return;
	}
	printf("\n|id|  |room charge| |icu charge| |other charge| |days admitted| |total charge| |initial balance| |remaining balance| |date claimed|");
	while(fscanf(f1,"%d %f %f %f %f %f %f %f %d %d %d\n",&userid,&room,&icu,&other,&day,&total,&k,&remaining_amount,&x,&y,&z)==11)
	{
		printf("\n %d     %f    %f    %f    %f      %f     %f        %f       %d %d %d",userid,room,icu,other,day,total,k,remaining_amount,x,y,z);
	}
	fclose(f1);getch();admin_services();
}

void specific_claim(){
	system("cls");
	printf("\t\t<<---------------------CLAIM HISTORY--------------------->>\t\t");
	int userid,x,y,z,id;
	float room,icu,other,day,total,k,remaining_amount;
	FILE *f1;
	f1=fopen("claim.txt","r");
	printf("\nEnter the userid you want to search: ");scanf("%d",&userid);fflush(stdin);
	if(f1==NULL){
		printf("\nFile could not be opened\n");fclose(f1);admin_services();getch();return;
	}
	printf("\n|id|  |room charge| |icu charge| |other charge| |days admitted| |total charge| |initial balance| |remaining balance| |date claimed|");
	while(fscanf(f1,"%d %f %f %f %f %f %f %f %d %d %d\n",&id,&room,&icu,&other,&day,&total,&k,&remaining_amount,&x,&y,&z)==11)
	{
		if(id==userid){
			printf("\n %d     %f    %f    %f    %f      %f     %f       %f       %d %d %d",userid,room,icu,other,day,total,k,remaining_amount,x,y,z);
		}
	}fclose(f1);getch();admin_services(userid);
}
	

void claim_lifetime(){
	system("cls");
	printf("\t\t<<------------------Total amount claimed by Lifetime Claim Limit subscribers------------------>>\t\t");
	int uid,userid,a,x,y,z;
	float k,room,icu,other,day,total,remaining_amount,initial,amount;
	char choice[10];
	FILE *f1;
	FILE *f2;
	f1=fopen("subs.txt","r");
	f2=fopen("claim.txt","r");
	if(f1==NULL && f2==NULL){
		printf("\nFile could not be opened\n");fclose(f1);fclose(f2);admin_services();getch();
	}
	while(fscanf(f1,"%d %d %s %f",&uid,&a,choice,&k)==4)
	{
		while(fscanf(f2,"%d %f %f %f %f %f %f %f %d %d %d\n",&userid,&room,&icu,&other,&day,&total,&initial,&remaining_amount,&x,&y,&z)==11){
			if((uid==userid)&&strcmp(choice,"lifetime")==0)
			{
				amount=amount+total;		
			}
		}
    }
    fclose(f1);
    fclose(f2);
    printf("\n\nTotal amount claimed by Lifetime Claim Limit subscribers is:%f",amount);getch();admin_services();
}

void claim_annual(){
	system("cls");
	printf("\t\t<<-----------Total number of Annual Claim Limit subscribers who have exhausted all their eligible amount------------>>\t\t");
	int uid,a,count;
	char choice[10];
	float k;
	FILE *f1;
	f1=fopen("subs.txt","r");
	if(f1==NULL){
		printf("\nFile could not be opened\n");getch();fclose(f1);admin_services();
	}
		while(fscanf(f1,"%d %d %s %f",&uid,&a,choice,&k)==4)
	{
		if(strcmp(choice,"annual")==0 && k==0){
			count=count+1;	
		}
	} 
	fclose(f1);
	printf("\n\nTotal number of Annual Claim Limit subscribers who have exhausted all their eligible amount is: %d",count);getch();admin_services();
}


